import flet as ft

# 참고 사이트, 블로그
# https://sianux1209.github.io
# https://velog.io/


def main(page: ft.Page):
    page.appbar = ft.AppBar(
        # leading=ft.Icon(ft.icons.PALETTE),
        leading_width=40,
        title=ft.Text("AHNTH64 안쓰64"),
        center_title=False,
        bgcolor=ft.colors.PURPLE,
        actions=[
            ft.IconButton(ft.icons.HOME, tooltip="홈"),
            ft.IconButton(ft.icons.APPS, tooltip="개발 앱"),
            ft.IconButton(ft.icons.DOCUMENT_SCANNER, tooltip="튜토리얼, 강좌 문서"),
            ft.IconButton(ft.icons.MESSAGE, tooltip="이슈 정리 블로그"),
        ],
    )
    md_file = open("readme.md")
    md = md_file.read()
    md_file.close()

    # page.add(ft.Text("몸통 블라블라 이게 잇어야 앱바가 보임."))
    page.add(
        ft.Markdown(
            md, selectable=True, extension_set=ft.MarkdownExtensionSet.GITHUB_WEB
        )
    )


ft.app(target=main, view=ft.AppView.WEB_BROWSER)
